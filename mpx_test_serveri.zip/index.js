import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";

const server = new McpServer({
  name: "MyLocalServer",
  version: "1.0.0",
});

// Добавляем инструмент
server.tool("get_time", "Возвращает текущее время сервера", {}, async () => {
  return {
    content: [{ type: "text", text: new Date().toLocaleTimeString() }],
  };
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

main().catch(console.error);
